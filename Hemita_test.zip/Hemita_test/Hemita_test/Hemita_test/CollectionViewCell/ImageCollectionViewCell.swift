//
//  ImageCollectionViewCell.swift
//  Hemita_test
//
//  Created by apple on 30/08/21.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    //MARK:- Outlet connections

   
    @IBOutlet weak var imgView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
