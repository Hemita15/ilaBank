//
//  TableViewDetailModel.swift
//  Hemita_test
//
//  Created by apple on 30/08/21.
//

import Foundation

class TableViewDetailModel{
    var detailText: String
    var imgPath: String
    
    init(detailText: String, imgPath: String) {
        self.detailText = detailText
        self.imgPath = imgPath
    }
}
